import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.Color;

public class SlideShow extends JFrame {

	//Declare Variables for the buttons, panels and frames for the slideshow
	private JPanel slidePane;
	private JPanel textPane;
	private JPanel buttonPane;
	private CardLayout card;
	private CardLayout cardText;
	private JButton btnPrev;
	private JButton btnNext;
	private JLabel lblSlide;
	private JLabel lblTextArea;

	/**
	 * Create the application and call the initComponent method belowv to initialize.
	 */
	public SlideShow() throws HeadlessException {
		initComponent();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initComponent() {
		//Initialize variables to empty objects
		card = new CardLayout();
		cardText = new CardLayout();
		slidePane = new JPanel();
		textPane = new JPanel();
		textPane.setBackground(Color.BLUE);
		textPane.setBounds(5, 470, 790, 50);
		textPane.setVisible(true);
		buttonPane = new JPanel();
		btnPrev = new JButton();
		btnNext = new JButton();
		lblSlide = new JLabel();
		lblTextArea = new JLabel();

		//Setup frame attributes
		setSize(800, 600);
		setLocationRelativeTo(null);
		setTitle("Top 5 Destinations SlideShow");
		getContentPane().setLayout(new BorderLayout(10, 50));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		//Setting the layouts for the panels
		slidePane.setLayout(card);
		textPane.setLayout(cardText);
		
		//below is logic to add each of the slides and text.  These will also call to the Next and Previous
		//button methods to make them function properly
		//This is an algorithm that will manipulate the data in the getResizeIcon and getTextDescription
		//data structures through the use of the button algorithms below. 
		//The initComponent method has this segment of code below which  uses a postfix increment operator that 
		//assigns a number first then adds one to the given value incrementally.  This algorithm is then linked
		//to the previous and next buttons which identify which number the increment operator assigned, and uses that 
		//number to pull from both data structures and combine them into one slide frame 
		
		for (int i = 1; i <= 5; i++) {
			lblSlide = new JLabel();
			lblTextArea = new JLabel();
			lblSlide.setText(getResizeIcon(i));
			lblTextArea.setText(getTextDescription(i));
			slidePane.add(lblSlide, "card" + i);
			textPane.add(lblTextArea, "cardText" + i);
		}

		getContentPane().add(slidePane, BorderLayout.CENTER);
		getContentPane().add(textPane, BorderLayout.SOUTH);

		buttonPane.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));
//calls to the Previous button and adds text 
		btnPrev.setText("Previous");
		btnPrev.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				goPrevious();
			}
		});
//calls to the Next button and adds text
		buttonPane.add(btnPrev);

		btnNext.setText("Next");
		btnNext.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				goNext();
			}
		});
		buttonPane.add(btnNext);

		getContentPane().add(buttonPane, BorderLayout.SOUTH);
	}

	/**
	 * 	//The initComponent method has this segment of code as an algorithm below which  identifies which number the increment 
	 * operator assigned, by using both the previous and next buttons, determine the 
	 * line number to pull from both data structures and combine them into one slide frame 
	 * Previous Button Functionality.  Is linked to the previous code to add functionality. It will use
	 * the increment operator to go back one number from the currently assigned one, then go back to the previous pane
	 */
	private void goPrevious() {
		card.previous(slidePane);
		cardText.previous(textPane);
	}
	
	/**
	 * Next Button Functionality.  Is linked to the previous code to add functionality. 
	 * It will use
	 * the increment operator to go ahead one number from the currently assigned one, then go to the next pane
	 */
	private void goNext() {
		card.next(slidePane);
		cardText.next(textPane);
	}

	/**
	 * The following getResizeIcon method is a data structure that is used to store image and image 
	 * sizing data.  This was enhanced to pull in images from the resource file and define their measurements.  
	 * This is the Method to get the images.  It links to imagery in the resource file folder
	 * The button code pulls back to this structure, determining which image to display
	 */
	private String getResizeIcon(int i) {
		String image = ""; 
		if (i==1){
			image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/Bahamas.jpg") + "'</body></html>";
		} else if (i==2){
			image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/Disneyworld.jpg") + "'</body></html>";
		} else if (i==3){
			image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/hawaii.jpg") + "'</body></html>";
		} else if (i==4){
			image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/jungle.jpg") + "'</body></html>";
		} else if (i==5){
			image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/Matterhorn.jpg") + "'</body></html>";
		}
		return image;
	}
	
	/**
	 * The following getTextDescription method is a data structure which is used to store descriptive data for each image
	 * This is the Method to get the text values for each slideshow image, The button code pulls back to this structure,
	 * determining which text to display
	 */
	private String getTextDescription(int i) {
		String text = ""; 
		if (i==1){
			text = "<html><body><font size='5'>#1 The Bahamas.</font> <br>Detox your body while soaking up spectacular ocean views and beaches!</body></html>";
		} else if (i==2){
			text = "<html><body><font size='5'>#2 Disneyworld.</font> <br>Relive your childhood and recover your inner wellness at the Happiest Place on Earth!</body></html>";
		} else if (i==3){
			text = "<html><body><font size='5'>#3 Hawaii.</font> <br>Swim with turtles and explore the best beaches in the World!  No better way to unclutter your mind and body!</body></html>";
		} else if (i==4){
			text = "<html><body><font size='5'>#4 South America.</font> <br>Venture into unexplored jungles and meet exotic new wildlife! Let the experience distract your mind from your troubles!</body></html>";
		} else if (i==5){
			text = "<html><body><font size='5'>#5 Switzerland.</font> <br>Hike the Matterhorn and explore Swiss culture!  Get fit in mind and body while enjoying the outdoors!</body></html>";
		}
		return text;
	}
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				SlideShow ss = new SlideShow();
				ss.setVisible(true);
			}
		});
	}
}