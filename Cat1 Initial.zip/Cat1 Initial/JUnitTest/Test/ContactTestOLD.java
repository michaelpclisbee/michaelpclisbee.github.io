import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactTest {
	 protected String contactID, firstNameTest, lastNameTest, phoneTest,
	 addressTest;
	 protected String tooLongContactID, tooLongFirstName, tooLongLastName,
	 tooLongPhone, tooShortPhone, tooLongAddress;
	 @BeforeEach
	 void setUp() {
	 contactID = "1029F847A6";
	 firstNameTest = "Mike";
	 lastNameTest = "Jones";
	 phoneTest = "5558675309";
	 addressTest = "1 Sweetwater Park AL 36756";
	 tooLongContactID = "112233445566778899";
	 tooLongFirstName = "MikeMikeMike";
	 tooLongLastName = "JonesJonesJonesJones";
	 tooLongPhone = "555123456789";
	 tooShortPhone = "1234567";
	 tooLongAddress = "110 Sweetwater Park Loop,  Alabama,  36756";
	 }
	 
	 @Test
	 void contactTest() {
	 Contact contact = new Contact();
	 assertAll("constructor",
	 ()
	 -> assertNotNull(contact.getContactID()),
	 ()
	 -> assertNotNull(contact.getFirstName()),
	 ()
	 -> assertNotNull(contact.getLastName()),
	 ()
	 -> assertNotNull(contact.getPhone()),
	 () -> assertNotNull(contact.getAddress()));
	 }
	 @Test
	 void contactIDConstructorTest() {
	 Contact contact = new Contact();
	 assertAll("constructor one",
	 ()
	 -> assertEquals(contactID, contact.getContactID()),
	 ()
	 -> assertNotNull(contact.getFirstName()),
	 ()
	 -> assertNotNull(contact.getLastName()),
	 ()
	 -> assertNotNull(contact.getPhone()),
	 () -> assertNotNull(contact.getAddress()));
	 }
	 @Test
	 void contactIdAndFirstNameConstructorTest() {
	 Contact contact = new Contact(contactID, firstNameTest);
	 assertAll("constructor two",
	 ()
	 -> assertEquals(contactID, contact.getContactID()),
	 ()
	 -> assertEquals(firstNameTest, contact.getFirstName()),
	 ()
	 -> assertNotNull(contact.getLastName()),
	 ()
	 -> assertNotNull(contact.getPhone()),
	 () -> assertNotNull(contact.getAddress()));
	 }
	 