import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactTest {
	 protected String contactID, firstNameTest, lastNameTest, phoneTest,
	 addressTest;
	 protected String tooLongContactID, tooLongFirstName, tooLongLastName,
	 tooLongPhone, tooShortPhone, tooLongAddress;
	 @BeforeEach
	 void setUp() {
	 contactID = "1029F847A6";
	 firstNameTest = "Mike";
	 lastNameTest = "Jones";
	 phoneTest = "5558675309";
	 addressTest = "1 Sweetwater Park AL 36756";
	 tooLongContactID = "112233445566778899";
	 tooLongFirstName = "MikeMikeMike";
	 tooLongLastName = "JonesJonesJonesJones";
	 tooLongPhone = "555123456789";
	 tooShortPhone = "1234567";
	 tooLongAddress = "110 Sweetwater Park Loop,  Alabama,  36756";
	 }
	 
	 @Test
	 //This code verifies that each of the objects are not null or not empty.
	 //If the passed parameter came up null, the test case would fail.
	 void contactTest() {
	 Contact contact = new Contact();
	 assertAll("constructor",
	 ()
	 -> assertNotNull(contact.getContactID()),
	 ()
	 -> assertNotNull(contact.getFirstName()),
	 ()
	 -> assertNotNull(contact.getLastName()),
	 ()
	 -> assertNotNull(contact.getPhone()),
	 () -> assertNotNull(contact.getAddress()));
	 }
	 @Test
	 //This code verifies that each of the objects are not null or not empty.  As well, it includes
	 //an added assertEquals() method to ensure that in this case the contactID is equally defined by the
	 //object entered.  
	 //If the passed parameter came up null, the test case would fail.
	 void contactIDConstructorTest() {
	 Contact contact = new Contact();
	 assertAll("constructor one",
	 ()
	 -> assertEquals(contactID, contact.getContactID()),
	 ()
	 -> assertNotNull(contact.getFirstName()),
	 ()
	 -> assertNotNull(contact.getLastName()),
	 ()
	 -> assertNotNull(contact.getPhone()),
	 () -> assertNotNull(contact.getAddress()));
	 }
	 @Test
	 //This code verifies that each of the objects are not null or not empty.  As well, it includes
	 //an added assertEquals() method to validate that in this case the contactID as well as the 
	 //firstName is equally defined by the object entered.  
	 //If the passed parameter came up null, the test case would fail, and a runtime exception would be thrown.
	 void contactIdAndFirstNameConstructorTest() {
	 Contact contact = new Contact(contactID, firstNameTest);
	 assertAll("constructor two",
	 ()
	 -> assertEquals(contactID, contact.getContactID()),
	 ()
	 -> assertEquals(firstNameTest, contact.getFirstName()),
	 ()
	 -> assertNotNull(contact.getLastName()),
	 ()
	 -> assertNotNull(contact.getPhone()),
	 () -> assertNotNull(contact.getAddress()));
	 }
	 @Test
	 //This code verifies that Phone and Address are not null or not empty.  As well, it includes
	 //an added assertEquals() method to validate that in this case the contactID as well as the 
	 //firstName AND lastName are equally defined by the object entered.  
	 //If the passed parameter came up null, or there was
	 //no match between assertEquals(), the test case would fail, and a runtime exception would be thrown.
	 void contactIdAndFullNameConstructorTest() {
	 Contact contact = new Contact(contactID, firstNameTest, lastNameTest);
	 assertAll("constructor three",
	 ()
	 -> assertEquals(contactID, contact.getContactID()),
	 ()
	 -> assertEquals(firstNameTest, contact.getFirstName()),
	 ()
	 -> assertEquals(lastNameTest, contact.getLastName()),
	 ()
	 -> assertNotNull(contact.getPhone()),
	 () -> assertNotNull(contact.getAddress()));
	 }
	 @Test
	 //This code adds to the previous code including now an assertEquals for the phone number
	 //If the passed parameter for address came up null, or there was
	 //no match between assertEquals(), the test case would fail, and a runtime exception would be thrown.
	 void contactIdFullNamePhoneNumberConstructorTest() {
	 Contact contact =
	 new Contact(contactID, firstNameTest, lastNameTest, phoneTest);
	 assertAll("constructor four",
	 ()
	 -> assertEquals(contactID, contact.getContactID()),
	 ()
	 -> assertEquals(firstNameTest, contact.getFirstName()),
	 ()
	 -> assertEquals(lastNameTest, contact.getLastName()),
	 ()
	 -> assertEquals(phoneTest, contact.getPhone()),
	 () -> assertNotNull(contact.getAddress()));
	 }
	 @Test
	 //This code adds to the previous code including an assertEquals() for all variables
	 //If there was no match between assertEquals(), the test case would fail, and 
	 //a runtime exception would be thrown.
	 void allTheProperThingsConstructorTest() {
	 Contact contact = new Contact(contactID, firstNameTest, lastNameTest,
	 phoneTest, addressTest);
	 assertAll("constructor all",
	 ()
	 -> assertEquals(contactID, contact.getContactID()),
	 ()
	 -> assertEquals(firstNameTest, contact.getFirstName()),
	 ()
	 -> assertEquals(lastNameTest, contact.getLastName()),
	 ()
	 -> assertEquals(phoneTest, contact.getPhone()),
	 () -> assertEquals(addressTest, contact.getAddress()));
	 }
	 @Test
	 //This code involves updating the FirstName. The code will throw up an exception if there is either
	 //no data to match, or the name is too long as specified in the too long parameters stated above. 
	 void updateFirstNameTest() {
	 Contact contact = new Contact();
	 contact.updateFirstName(firstNameTest);
	 assertAll(
	 "first name",
	 ()
	 -> assertEquals(firstNameTest, contact.getFirstName()),
	 ()
	 -> assertThrows(IllegalArgumentException.class,
			 () -> contact.updateFirstName(null)),
			 ()
			 -> assertThrows(IllegalArgumentException.class,
			 () -> contact.updateFirstName(tooLongFirstName)));
			 }
			 @Test
			 //This code involves updating the LastName. The code will throw up an exception if there is either
	         //no data to match, or the name is too long as specified in the too long parameters stated above. 
			 void updateLastNameTest() {
			 Contact contact = new Contact();
			 contact.updateLastName(lastNameTest);
			 assertAll(
			 "last name",
			 ()
			 -> assertEquals(lastNameTest, contact.getLastName()),
			 ()
			 -> assertThrows(IllegalArgumentException.class,
			 () -> contact.updateLastName(null)),
			 ()
			 -> assertThrows(IllegalArgumentException.class,
			 () -> contact.updateLastName(tooLongFirstName)));
			 }
			 @Test
			 //This code involves updating the PhoneNumber. The code will throw up an exception if there is either
			 //no data to match, or the name is too long as specified in the too long parameters stated above, or too short
			 //as specified in the tooshort parameters above. As well if the phone number matches the contactID.  
			 void updatePhoneNumberTest() {
			 Contact contact = new Contact();
			 contact.updatePhone(phoneTest);
			 assertAll("phone number",
			 ()
			 -> assertEquals(phoneTest, contact.getPhone()),
			 ()
			 -> assertThrows(IllegalArgumentException.class,
			 () -> contact.updatePhone(null)),
			 ()
			 -> assertThrows(
			 IllegalArgumentException.class,
			 () -> contact.updatePhone(tooLongPhone)),
			 ()
			 -> assertThrows(
			 IllegalArgumentException.class,
			 () -> contact.updatePhoneNumber(tooShortPhone)),
			 ()
			 -> assertThrows(IllegalArgumentException.class,
			 () -> contact.updatePhoneNumber(contactID)));
			 }
			 @Test
			 //This code involves updating the Address. The code will throw up an exception if there is either
			 //no data to match, or the name is too long as specified in the too long parameters stated above  
			 void updateAddressTest() {
			 Contact contact = new Contact();
			 contact.updateAddress(addressTest);
			 assertAll("phone number",
			 ()
			 -> assertEquals(addressTest, contact.getAddress()),
			 ()
			 -> assertThrows(IllegalArgumentException.class,
			 () -> contact.updateAddress(null)),
			 ()
			 -> assertThrows(IllegalArgumentException.class,
			 () -> contact.updateAddress(tooLongAddress)));
			 }
			 @Test
			 //This code involves updating the ContactID. The code will throw up an exception if there is either
			 //no data to match, or the ContactID is too long as specified in the too long parameters stated above  
			 void updateContactIdTest() {
			 Contact contact = new Contact();
			 contact.updateContactID(contactID);
			 assertAll(
			 "contact ID",
			 ()
			 -> assertEquals(contactID, contact.getContactID()),
			 ()
			 -> assertThrows(IllegalArgumentException.class,
			 () -> contact.updateContactID(null)),
			 ()
			 -> assertThrows(IllegalArgumentException.class,
			 () -> contact.updateContactID(tooLongContactID)));
			 }}
