

public class Contact {
	   //contact variables
	   private String firstName;
	   private String lastName;
	   private String address;
	   private String phone;
	   private String contactID;
	   //constructor
	   public Contact(String firstName, String lastName, String address) {
	       //first name cannot be longer than 10 characters and cannot be null
	       if (firstName.length() > 10 || firstName == null) {
	           throw new IllegalArgumentException("Invalid Input");
	       }
	       //last name cannot be longer than 10 characters and cannot be null
	       if (lastName.length() > 10 || lastName == null) {
	           throw new IllegalArgumentException("Invalid Input");
	       }
	       //address cannot be longer than 30 characters and cannot be null
	       if (address.length() > 30 || address == null) {
	           throw new IllegalArgumentException("Invalid Input");
	       }
	       //phone must be exactly 10 digits and cannot be null
	       if (phone.length() != 10 || phone == null) {
	           throw new IllegalArgumentException("Invalid Input");
	       }
	       //contact ID cannot be longer than 10 characters and cannot be null or updated
	       if (contactID.length() > 10 || contactID == null) {
	           throw new IllegalArgumentException("Invalid Input");
	       }
	       this.firstName = firstName;
	       this.lastName = lastName;
	       this.address = address;
	       this.phone = phone;
	       this.contactID = contactID;
	   }
	   public Contact(Object object, String firstname2, String lastname2) {
		// TODO Auto-generated constructor stub
	}
	public Contact(String newUniqueId, String firstname2, String lastname2, String phonenumber) {
		// TODO Auto-generated constructor stub
	}
	public Contact(Object newUniqueId) {
		// TODO Auto-generated constructor stub
	}
	
	public Contact(Object newUniqueId, String firstname2, String lastname2, String phonenumber, String address2) {
		// TODO Auto-generated constructor stub
	}
	
	public Contact(String newUniqueId) {
		// TODO Auto-generated constructor stub
	}
	
	public Contact() {
		// TODO Auto-generated constructor stub
	}
	public Contact(String contactID2, String firstNameTest) {
		// TODO Auto-generated constructor stub
	}
	public void setFirstName(String firstName) {
	       this.firstName = firstName;
	   }
	   public void setLastName(String lastName) {
	       this.lastName = lastName;
	   }
	   public void setAddress(String address) {
	       this.address = address;
	   }
	   public void setPhone(String phone) {
	       this.phone = phone;
	   }
	   public void setContactID(String contactID) {
	       this.contactID = contactID;
	   }
	   @Override
	   public String toString() {
	       return "Contact{" +
	               "firstName='" + firstName + '\'' +
	               ", lastName='" + lastName + '\'' +
	               ", address='" + address + '\'' +
	               ", phone='" + phone + '\'' +
	               ", contactID='" + contactID + '\'' +
	               '}';
	   }
	   public String getFirstName() {
	       return firstName;
	   }
	   public String getLastName() {
	       return lastName;
	   }
	   public String getAddress() {
	       return address;
	   }
	   public String getPhone() {
	       return phone;
	   }
	   public String getContactID() {
	       return contactID;
	   }
	public void updateFirstName(String firstName2) {
		// TODO Auto-generated method stub
		
	}
	public void updateLastName(String lastName2) {
		// TODO Auto-generated method stub
		
	}
	public void updatePhoneNumber(String phoneNumber) {
		// TODO Auto-generated method stub
		
	}
	public void updateAddress(String address2) {
		// TODO Auto-generated method stub
		
	}
	public void updatePhone(String phoneTest) {
		// TODO Auto-generated method stub
		
	}
	public void updateContactID(String contactID2) {
		// TODO Auto-generated method stub
		
	}
	
	}